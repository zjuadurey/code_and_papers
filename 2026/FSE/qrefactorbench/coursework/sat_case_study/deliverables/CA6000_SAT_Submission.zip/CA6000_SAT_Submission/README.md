# CA6000 SAT Prediction — Start Here

Selected topic: Learning to Predict Boolean Satisfiability, inspired by QRefactorBench.

1. Slides: coursework/sat_case_study/deliverables/CA6000_SAT_PRESENTATION.pptx
2. Report: coursework/sat_case_study/deliverables/CA6000_SAT_REPORT.pdf
3. Full instructions: coursework/sat_case_study/README.md
4. Speaker notes: coursework/sat_case_study/SPEAKER_NOTES.md

From this extracted directory:

    python -m coursework.sat_case_study.app

Open http://127.0.0.1:8766. Or retrain into a NEW directory:

    python -m coursework.sat_case_study.train --output ./reproduced_results
    python -m pytest -q coursework/sat_case_study/test_study.py

Use an environment with requirements.txt. Dependencies are not installed automatically.
Tested on Python 3.10.21, CPU. Supplied weights/data work offline; no API key or QPU.
Add name/student ID to the report and title slide; read/reproduce the work before submission.
AI coding assistance is disclosed. No claim of solver replacement or quantum advantage.
The original repository license status is preserved in LICENSE; this is not a public release.
