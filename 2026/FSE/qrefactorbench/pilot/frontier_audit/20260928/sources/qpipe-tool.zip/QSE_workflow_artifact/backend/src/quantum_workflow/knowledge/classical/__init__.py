"""Classical reference solvers: produce classical baselines for common problem types so stage 5 can cross-check them."""
