"""quantum_workflow.api subpackage.

Holds the FastAPI app factory, route definitions, and dependency-injection helpers.
"""
