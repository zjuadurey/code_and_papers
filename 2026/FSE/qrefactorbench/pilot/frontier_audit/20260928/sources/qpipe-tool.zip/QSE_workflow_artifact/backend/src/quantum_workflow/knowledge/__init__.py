"""quantum_workflow.knowledge subpackage.

Knowledge base for the generative pipeline: algorithm knowledge
entries, the quantum building-block library, and classical reference
solvers. Supersedes the older quantum_workflow.catalog package.
"""
