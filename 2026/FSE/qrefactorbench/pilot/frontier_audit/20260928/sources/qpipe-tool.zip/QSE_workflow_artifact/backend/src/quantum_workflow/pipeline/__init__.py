"""
Pipeline package entry point.

Exposes the pipeline orchestrator and the StageError exception as
public, package-level API so callers can import directly from
`quantum_workflow.pipeline` without depending on internal module layout.
"""
