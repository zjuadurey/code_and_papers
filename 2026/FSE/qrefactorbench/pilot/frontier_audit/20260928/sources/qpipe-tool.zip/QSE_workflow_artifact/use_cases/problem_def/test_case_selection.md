Definition of test case selection:

Given a test suite $T = \{t_0, \cdots, t_{n−1}\}$ with a set of testing attributes for the software under test and the corresponding testing objectives $F = \{f_0, \cdots, f_{m−1}\}$, test case selection aims to select a subset $T' \in T$ to satisfy all objectives as much as possible. Each objective is associated with one of the attributes of the test cases.