"""Top-level package for quantum_workflow.

Exposes build_pipeline_from_settings as the single factory that assembles
the full quantum workflow pipeline and its trace store from a Settings
object.
"""
