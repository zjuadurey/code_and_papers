"""Quantum building-block library: vetted quantum function modules that stage-4 generated code can import directly."""
