"""
Sandbox package entry point.

Provides an isolated execution environment that runs pipeline-generated
quantum-circuit code inside a restricted subprocess, preventing
untrusted code from affecting the host process.
"""
