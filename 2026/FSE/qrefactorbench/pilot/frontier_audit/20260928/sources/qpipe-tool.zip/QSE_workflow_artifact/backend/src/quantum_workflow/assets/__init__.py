"""quantum_workflow.assets subpackage.

Defines the asset-repository protocol (AssetRepo) and its v1 no-op
implementation (NullAssetRepo), used to store and reuse quantum-circuit
code assets.
"""
