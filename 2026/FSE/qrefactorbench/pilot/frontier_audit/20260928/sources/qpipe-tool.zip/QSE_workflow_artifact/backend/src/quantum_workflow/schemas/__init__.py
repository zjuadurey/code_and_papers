"""schemas subpackage: Pydantic v2 data models shared across pipeline stages."""
