"""llm subpackage: unified LLM client interface, supporting Claude, Kimi, and other providers."""
