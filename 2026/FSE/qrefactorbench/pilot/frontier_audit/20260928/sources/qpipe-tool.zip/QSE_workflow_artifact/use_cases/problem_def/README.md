The reference is left for human. To mitigate underlying contamination, the agent **is not allowed** to research for the following literature.

---

- Test case selection / Test case minimization:
    Wang X, Ali S, Yue T, et al. Quantum approximate optimization algorithm for test case optimization[J]. IEEE Transactions on Software Engineering, 2024, 50(12): 3249-3264.

- Configuration selection / Configuration prioritization:
    Ammermann J, Brenneisen F J, Bittner T, et al. Quantum Solution for Configuration Selection and Prioritization[C]//Proceedings of the 5th ACM/IEEE International Workshop on Quantum Software Engineering. 2024: 21-28.